/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cersotp5;

/**
 *
 * @author info7
 */
public class CersoTP6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        cerso6 ventana = new cerso6();
        
        ventana.setVisible(true);
        
    }
    
}
